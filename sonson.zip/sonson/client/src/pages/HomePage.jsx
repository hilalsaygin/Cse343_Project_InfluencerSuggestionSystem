import React from "react";
import { Brand } from "../components";

import "./indexPages.css";
import "./homepage.css";

export default function HomePage() {
  return (
    <div className="gradient__bg">
      <Brand />
    </div>
  );
}
