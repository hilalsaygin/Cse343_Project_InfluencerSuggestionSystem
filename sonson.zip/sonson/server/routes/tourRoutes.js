const express = require("express");
const tourController = require("./../controllers/tourController");
const router = express.Router();

router.param("username", tourController.checkUsername);

router.route("/categories").get(tourController.getToursByCategory);

router.route("/popular").get(tourController.getPopular);

router
  .route("/")
  .get(tourController.getAllTours)
  .patch(tourController.updateTour)
  .post(tourController.createTour);

router
  .route("/:username")
  .get(tourController.getTour)
  .delete(tourController.deleteTour);

module.exports = router;
