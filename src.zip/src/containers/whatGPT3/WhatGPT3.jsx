import React from 'react';
import './whatGPT3.css';

const WhatGPT3 = () => {
  return (
    <div>WhatGPT3</div>
  )
}

export default WhatGPT3